//
//  ViewController.swift
//  Pandiri_Govinda
//
//  Created by Pandiri,Govinda R on 2/1/22.
//

import UIKit

class ViewController: UIViewController {

    
@IBOutlet weak var firstNameTextField: UITextField!
    
@IBOutlet weak var lastNameTextField: UITextField!
    

@IBOutlet weak var onClickOfSubmit: UIButton!
    
@IBOutlet weak var onClickOfReset: UIButton!
    
@IBOutlet weak var fullNameLabel: UILabel!
    
@IBOutlet weak var display: UILabel!
    
@IBOutlet weak var initialsLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        var firstName = firstNameTextField.text!
        var lastName = lastNameTextField.text!
        let ini1 = firstName.prefix(1)
        let ini2 = lastName.prefix(1)
        fullNameLabel.text = "Full Name: \(firstName),\(lastName)"
        initialsLabel.text = "Initials: \(ini1)\(ini2)"
        display.text = "Details"
    }
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text = " "
        lastNameTextField.text = " "
        fullNameLabel.text = " "
        initialsLabel.text = " "
        display.text = " "
        firstNameTextField.becomeFirstResponder()
        
        
    }
}

